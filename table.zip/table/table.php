 <html>
	
	<head>
		<title>BOOK TABLE </title>
		<link rel="stylesheet" type="text/css" href="tablecss.css">
	</head>
	
	<body class="body" >
		<table>
			<tr id="menubar">
				<td id="td"><select id="select" > 	
				
					<option id="option" ><b>LOGIN</b><option>
					<option id="option">SIGNUP<option>
					<option id="option">LOGOUT<option>
				
				</select></td>
				<td id="td">TABLE</td>
				<td id="td" style="float:center" >LOGIN</td>
			</tr>
		</table>
			
		<a href=""><button id="homebtn" style="float:right">HOME</button></a>
		<a href="">	<button id="backbtn" >BACK</button></a>
		
		<center>
				<div id="div">
					<div id="subdiv">
						<center id="title">
					<span >BOOK TABLE</span>
					</center>
					</div>
				</div>
		</center>
				
	</body>
</html>

<?php
	$host="localhost:3306";
	$user="root";
	$pwd="";
	
	$conn=mysqli_connect($host,$user,$pwd);
	$sql="CREATE DATABASE dineout";
	if($conn->query($sql) ===TRUE)
		{
		echo "DATABASE created successfully";
		}
	else
	{
		echo "error".$conn->error;
	}

?>